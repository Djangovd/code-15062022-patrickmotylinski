from enum import Enum

class df_cols(Enum):
    gender = "Gender"
    height_cm = "HeightCm"
    weight_kg = "WeightKg"

    BMI = "BMI"
    BMI_category = "BMI_category"
    Health_risk = "Health_risk"